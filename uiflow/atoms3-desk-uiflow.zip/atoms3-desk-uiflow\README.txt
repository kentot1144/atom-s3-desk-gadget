AtomS3 Desk Gadget - UIFlow2 upload bundle
===========================================

This is the device-side MicroPython only. The hub (PC side) is separate;
get it from the GitHub repository listed below.

WHAT IS IN HERE
  main.py               Paste this into UIFlow2's Python editor (replaces the
                        generated main.py). It starts Wi-Fi, then the app.
  app.py                Tiny shim: imports desk.app.run
  desk/                 The actual application, 11 small modules.
  config.json.example   Rename to config.json and fill in YOUR values.

DO NOT PUBLISH YOUR FILLED-IN config.json.
It contains Wi-Fi passwords and hub addresses. Use placeholders in any
public UIFlow Project Zone project, and add the real file only to your
own device.

HOW TO INSTALL IN UIFLOW2 (AtomS3)
  1. Open https://uiflow2.m5stack.com/ and log in.
  2. Select controller: AtomS3. Create a new project.
  3. Switch the editor to "Python" mode.
  4. Open "Project Files" and upload app.py, the whole desk/ folder,
     and a config.json you made from config.json.example.
     Keep the paths exactly as shown here (desk/ must be a folder).
  5. Replace the contents of the editor's main.py with the main.py
     from this bundle, then Save.
  6. Connect the AtomS3 by USB, choose Run Once to test, then
     Run Always to keep it on the device.
  7. In the firmware flashing options choose "Run main.py directly"
     if you want the gadget to start without the UIFlow menu.

CONFIG
  config.json.example has placeholder values. Set at minimum:
    wifi.networks  - list of {ssid, password} entries; the first is "home"
    hub.urls       - your hub URL, e.g. http://192.168.1.10:8765
    location.tz    - your UTC offset in hours
  The device must be able to reach the hub on the same network (or via a
  public hostname). Without the hub, pages still render but Spotify,
  weather, PC stats and notices will be empty.

MORE INFO / FULL SOURCE
  https://github.com/kentot1144/atom-s3-desk-gadget
  See docs/UIFLOW.md in the repository for Project Zone publish steps.
